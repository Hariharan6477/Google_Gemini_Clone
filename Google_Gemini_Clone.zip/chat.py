import google.generativeai as genai


genai.configure(api_key='AIzaSyCC-yCZ7KVv7UazA_qUbmfQRjjqCsvbUWk')
model = genai.GenerativeModel('gemini-pro')

def chat(text):
    response = model.generate_content(text)
    return response.text



